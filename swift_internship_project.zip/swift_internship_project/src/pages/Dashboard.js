// src/pages/Dashboard.js
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const PAGE_SIZES = [10, 50, 100];
const COMMENTS_API = "https://jsonplaceholder.typicode.com/comments";

const Dashboard = () => {
  const navigate = useNavigate();
  const [comments, setComments] = useState([]);
  const [filteredComments, setFilteredComments] = useState([]);
  const [search, setSearch] = useState(localStorage.getItem("search") || "");
  const [sort, setSort] = useState(JSON.parse(localStorage.getItem("sort")) || { field: null, order: null });
  const [page, setPage] = useState(Number(localStorage.getItem("page")) || 1);
  const [pageSize, setPageSize] = useState(Number(localStorage.getItem("pageSize")) || 10);

  useEffect(() => {
    fetch(COMMENTS_API)
      .then((res) => res.json())
      .then((data) => setComments(data));
  }, []);

  useEffect(() => {
    let result = [...comments];
    if (search) {
      result = result.filter((item) =>
        item.name.toLowerCase().includes(search.toLowerCase()) ||
        item.email.toLowerCase().includes(search.toLowerCase()) ||
        item.body.toLowerCase().includes(search.toLowerCase())
      );
    }
    if (sort.field) {
      result.sort((a, b) => {
        const aVal = a[sort.field]?.toLowerCase?.() || a[sort.field];
        const bVal = b[sort.field]?.toLowerCase?.() || b[sort.field];
        if (aVal < bVal) return sort.order === "asc" ? -1 : 1;
        if (aVal > bVal) return sort.order === "asc" ? 1 : -1;
        return 0;
      });
    }
    setFilteredComments(result);
    localStorage.setItem("search", search);
    localStorage.setItem("sort", JSON.stringify(sort));
    localStorage.setItem("page", page);
    localStorage.setItem("pageSize", pageSize);
  }, [comments, search, sort, page, pageSize]);

  const handleSort = (field) => {
    if (sort.field !== field) return setSort({ field, order: "asc" });
    if (sort.order === "asc") return setSort({ field, order: "desc" });
    if (sort.order === "desc") return setSort({ field: null, order: null });
  };

  const paginatedData = filteredComments.slice((page - 1) * pageSize, page * pageSize);
  const totalPages = Math.ceil(filteredComments.length / pageSize);

  return (
    <div style={{ fontFamily: 'Segoe UI, sans-serif', backgroundColor: '#f5f7fa', minHeight: '100vh' }}>
      {/* Header */}
      <header style={{ backgroundColor: '#091540', color: 'white', padding: '1rem 2rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2 style={{ margin: 0, fontWeight: 'bold' }}>SWIFT</h2>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', cursor: 'pointer' }} onClick={() => navigate('/profile')}>
          <span>Leanne Graham</span>
          <div style={{ width: 40, height: 40, background: '#e2e8f0', borderRadius: '50%', display: 'flex', justifyContent: 'center', alignItems: 'center', fontWeight: 'bold', color: '#091540' }}>LG</div>
        </div>
      </header>

      {/* Content */}
      <div style={{ padding: '2rem', maxWidth: '1300px', margin: '0 auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <button style={blackButtonStyle} onClick={() => handleSort("postId")}>Sort Post ID</button>
            <button style={blackButtonStyle} onClick={() => handleSort("name")}>Sort Name</button>
            <button style={blackButtonStyle} onClick={() => handleSort("email")}>Sort Email</button>
          </div>
          <input
            type="text"
            placeholder="Search name, email, comment"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            style={{ padding: '10px', width: '300px', border: '1px solid #ccc', borderRadius: '5px' }}
          />
        </div>

        <div style={{ overflowX: 'auto', borderRadius: '10px', border: '1px solid #dcdfe6', backgroundColor: 'white' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead style={{ background: '#f4f6fb' }}>
              <tr>
                <th style={thStyle}>Post ID</th>
                <th style={thStyle}>Name</th>
                <th style={thStyle}>Email</th>
                <th style={thStyle}>Comment</th>
              </tr>
            </thead>
            <tbody>
              {paginatedData.map((item) => (
                <tr key={item.id}>
                  <td style={tdStyle}>{item.postId}</td>
                  <td style={tdStyle}>{item.name}</td>
                  <td style={tdStyle}>{item.email}</td>
                  <td style={tdStyle}>{item.body.slice(0, 50)}...</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '1rem', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          <span style={{ fontSize: '0.9rem' }}>1–{pageSize} of {filteredComments.length} items</span>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <button onClick={() => setPage((p) => Math.max(p - 1, 1))} disabled={page === 1} style={blackButtonStyle}>&lt;</button>
            <span style={{ fontSize: '0.9rem' }}>{page} / {totalPages}</span>
            <button onClick={() => setPage((p) => Math.min(p + 1, totalPages))} disabled={page === totalPages} style={blackButtonStyle}>&gt;</button>
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setPage(1);
              }}
              style={{ padding: '0.4rem', borderRadius: '4px', border: '1px solid #ccc' }}
            >
              {PAGE_SIZES.map(size => (
                <option key={size} value={size}>{size} / Page</option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};

const blackButtonStyle = {
  background: 'rgb(204, 204, 204)',
  color: '#000',
  padding: '8px 12px',
  border: '1px solid #ccc',
  borderRadius: '5px',
  cursor: 'pointer',
  fontSize: '0.9rem'
};

const thStyle = {
  textAlign: 'left',
  padding: '12px',
  fontWeight: '600',
  color: '#111827',
  fontSize: '0.9rem',
  borderBottom: '1px solid #d1d5db'
};

const tdStyle = {
  textAlign: 'left',
  padding: '12px',
  fontSize: '0.9rem',
  color: '#374151',
  borderBottom: '1px solid #f3f4f6'
};

export default Dashboard;
