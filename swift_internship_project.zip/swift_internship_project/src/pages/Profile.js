import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const USERS_API = "https://jsonplaceholder.typicode.com/users";

const Profile = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);

  useEffect(() => {
    fetch(USERS_API)
      .then((res) => res.json())
      .then((data) => setUser(data[0]));
  }, []);

  if (!user) return <div>Loading...</div>;

  const initials = user.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return (
    <div style={{ fontFamily: 'Segoe UI, sans-serif', backgroundColor: '#f4f6fa', minHeight: '100vh' }}>
      <header style={{ backgroundColor: '#091540', padding: '1rem 2rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: 'white' }}>
        <h2 style={{ margin: 0 }}>SWIFT</h2>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <span>{user.name}</span>
          <div style={{ background: '#e4e6eb', color: '#091540', borderRadius: '50%', width: 38, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold' }}>{initials}</div>
        </div>
      </header>

      <div style={{ padding: '2rem' }}>
        <button onClick={() => navigate("/")} style={{ background: 'none', border: 'none', color: '#091540', marginBottom: '1.5rem', fontSize: '1rem', cursor: 'pointer' }}>&larr; Welcome, {user.name}</button>

        <div style={{ backgroundColor: 'white', borderRadius: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.06)', padding: '2rem', maxWidth: '1000px', margin: 'auto' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
            <div style={{ background: '#f0f2f5', borderRadius: '50%', width: 56, height: 56, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem', fontWeight: 'bold' }}>{initials}</div>
            <div>
              <h2 style={{ margin: 0, fontSize: '1.25rem' }}>{user.name}</h2>
              <p style={{ margin: 0, color: 'gray' }}>{user.email}</p>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
            <div>
              <label style={{ fontSize: '0.85rem', fontWeight: '500', color: '#666' }}>User ID</label>
              <div style={{ marginTop: '0.3rem', background: '#f5f7fb', padding: '10px', borderRadius: '5px' }}>{user.id}</div>
            </div>
            <div>
              <label style={{ fontSize: '0.85rem', fontWeight: '500', color: '#666' }}>Name</label>
              <div style={{ marginTop: '0.3rem', background: '#f5f7fb', padding: '10px', borderRadius: '5px' }}>{user.name}</div>
            </div>
            <div>
              <label style={{ fontSize: '0.85rem', fontWeight: '500', color: '#666' }}>Email ID</label>
              <div style={{ marginTop: '0.3rem', background: '#f5f7fb', padding: '10px', borderRadius: '5px' }}>{user.email}</div>
            </div>
            <div>
              <label style={{ fontSize: '0.85rem', fontWeight: '500', color: '#666' }}>Address</label>
              <div style={{ marginTop: '0.3rem', background: '#f5f7fb', padding: '10px', borderRadius: '5px' }}>{user.address.street}, {user.address.city}</div>
            </div>
            <div>
              <label style={{ fontSize: '0.85rem', fontWeight: '500', color: '#666' }}>Phone</label>
              <div style={{ marginTop: '0.3rem', background: '#f5f7fb', padding: '10px', borderRadius: '5px' }}>{user.phone}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;